package com.cg.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.cg.bean.Admin;

public interface AdminDAO extends JpaRepository<Admin, Integer> {
	@Query("select a.password from Admin a where a.emailid=?1")
	public String getAdminPassword(String emailId);

	@Query("select u from Admin u where u.emailid=?1")
	public Admin existsByEmail(String emailId);

	@Transactional
	@Modifying
	@Query("update Admin u set u.password=?2 where u.emailid=?1")
	public void updatepassword(String email, String password);
}
