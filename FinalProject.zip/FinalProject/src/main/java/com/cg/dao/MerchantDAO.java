package com.cg.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.cg.bean.Merchant;

public interface MerchantDAO extends JpaRepository<Merchant, Integer> {
	@Query("select m.password from Merchant m where m.emailid=?1")
	public String getMerchantPassword(String emailId);

	@Query("select u from Merchant u where u.emailid=?1")
	public Merchant existsByEmail(String emailId);

	@Transactional
	@Modifying
	@Query("update Merchant u set u.password=?2 where u.emailid=?1")
	public void updatepassword(String email, String password);
}
