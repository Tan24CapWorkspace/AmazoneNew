package com.cg.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.bean.Return;

public interface ReturnDAO extends JpaRepository<Return, Integer>{

}
