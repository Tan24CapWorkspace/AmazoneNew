package com.cg.service;

import com.cg.inputFormats.PasswordEntity;

public interface passwordService {

	public PasswordEntity changepassword(PasswordEntity entity);
}
