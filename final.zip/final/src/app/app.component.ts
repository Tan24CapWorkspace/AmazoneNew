﻿import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from './Services/authentication.service';

@Component({
    selector: 'app',
    templateUrl: 'app.component.html'
})
export class AppComponent implements OnInit {
    
    loggedIn:boolean = false;

    ngOnInit(): void {
    }
    constructor(private service:AuthenticationService){
      
    }

    loggin():boolean{

        if (sessionStorage.length != 0) {
            //alert("login")
            return true
          }
          else {
            //alert("logout")
            return false
          }
    }

    
}