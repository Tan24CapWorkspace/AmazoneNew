﻿import { NgModule, Component }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Showcomponent } from './ShowFeature/show.component';
import { ProductService } from './Services/productService';
import { LoginComponent } from './login/login.component';
import { Admin } from './component/admin/admin.component';
import { MerchComponent } from './merch/merch.component';
import { Customer } from './customer/customer.component';
import { PasswordComponent } from './component/passwordComponent/getPasword';
import { SignUpComponent } from './component/signupComponent/app.signup';
import { ChangePasswordComponent } from './component/passcomponent/password';
import { LogoutComponent } from './logout/logout.component';
import { ShowUserComponent } from './component/showUser/showUser';
import { AddProductComponent } from './component/addproduct/addProduct';
import { GetAllMerchantComponent } from './component/showMerchant/app.getAllMerchant';
import { ShowProductComponent } from './component/showProduct/showProduct';
import { ShowDiscountComponent } from './component/showDiscount/showDiscount';
import { AddDiscountComponent } from './component/addDiscount/addDiscount';
import { ShowPromocodeComponent } from './component/showPromocode/showPromocode';
import { AddMerchantComponent } from './component/AddMerchant/app.addMerchant';


const routes: Routes=[
    {path:'home',component:Showcomponent},
    {path:'login',component:LoginComponent},
    {path:'admin',component:Admin},
    {path:'merchant',component:MerchComponent},
    {path:'customer',component:Showcomponent},
    {path:'forgotpassword', component:PasswordComponent},
    {path:'signup',component:SignUpComponent},
    {path:'changepassword',component:ChangePasswordComponent},
    {path:'logout',component:LogoutComponent},
    {path:"main", component: AppComponent},
    {path:'',redirectTo:'home', pathMatch:'full'},
  {path:'showUser',component:ShowUserComponent},
{path:'showMerchant',component:GetAllMerchantComponent},
{path:'addProduct',component:AddProductComponent},
{path:'showProduct',component:ShowProductComponent},
{path:'showDiscount',component:ShowDiscountComponent},
{path:'addDiscount',component:AddDiscountComponent},
{path:'showPromocode',component:ShowPromocodeComponent},
{path:'addMerchant',component:AddMerchantComponent}
   // {path:'registration', component: SignUpComponent}
  
]


@NgModule({
    imports: [
        BrowserModule,
        FormsModule,
        RouterModule.forRoot(routes),
        HttpClientModule
    ],
    declarations: [
        AppComponent,
        Showcomponent,
        LoginComponent,
        Customer,
        MerchComponent,
        PasswordComponent,
        SignUpComponent,
        ChangePasswordComponent,
        LogoutComponent,
        ShowUserComponent, AddProductComponent, GetAllMerchantComponent, ShowProductComponent, ShowDiscountComponent, AddDiscountComponent, ShowPromocodeComponent, AddMerchantComponent , Admin
  //      SignUpComponent
		],
    providers: [ ProductService],
    bootstrap: [AppComponent]
})

export class AppModule { 

}