﻿import { NgModule, Component }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Showcomponent } from './ShowFeature/show.component';
import { ProductService } from './Services/productService';
import { LoginComponent } from './login/login.component';
import { AdminComponent } from './admin/admin.component';
import { MerchComponent } from './merch/merch.component';
import { Customer } from './customer/customer.component';
import { PasswordComponent } from './component/passwordComponent/getPasword';
import { SignUpComponent } from './component/signupComponent/app.signup';
import { ChangePasswordComponent } from './component/passcomponent/password';

const routes: Routes=[
    {path:'home',component:Showcomponent},
    {path:'login',component:LoginComponent},
    {path:'admin',component:AdminComponent},
    {path:'merchant',component:MerchComponent},
    {path:'customer',component:Showcomponent},
    {path:'forgotpassword', component:PasswordComponent},
    {path:'signup',component:SignUpComponent},
    {path:'changepassword',component:ChangePasswordComponent},

    {path:'**',redirectTo:'home', pathMatch:'full'},
   // {path:'registration', component: SignUpComponent}
  
]


@NgModule({
    imports: [
        BrowserModule,
        FormsModule,
        RouterModule.forRoot(routes),
        HttpClientModule
    ],
    declarations: [
        AppComponent,
        Showcomponent,
        LoginComponent,
        AdminComponent,
        Customer,
        MerchComponent,
        PasswordComponent,
        SignUpComponent,
        ChangePasswordComponent
  //      SignUpComponent
		],
    providers: [ ProductService],
    bootstrap: [AppComponent]
})

export class AppModule { 

}