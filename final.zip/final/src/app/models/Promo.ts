export class Promo{

  promocodeId:number;
  promocode:string;

  constructor(promocodeId,promocode)
  {
      this.promocodeId=promocodeId;
      this.promocode=promocode;
  }
}
