import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../Services/authentication.service';
import {Admin} from '../admin/admin.component'
import {Merchant} from '../merch/merch.component'
import { DataService } from '../Services/data.service';
import { User1 } from '../user1/user.component';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  username=''
  password=''
  invalidLogin=false
  errorMessage='Wrong input!!! Please check...'
  userType:string

  public ad:Admin
  public cu:User1
  public me:Merchant
  public str:string
  public str1:string = "productId here!"

  constructor(private router:Router,private auth:AuthenticationService,private service:DataService) {}
    
  ngOnInit() {
  }

  handelLogin(){

    this.service.retrieveAdmin(this.username,this.password).subscribe(
      data=>{
        this.ad = data
        alert(this.ad.adminId)
        if(this.ad.emailid != ""){
        this.str = this.ad.adminId+""
        sessionStorage.setItem('admin', this.str)
        this.router.navigate(['admin'])
        alert("Hello1")
        alert(sessionStorage.length)
        }else{
          this.service.retrieveCustomer(this.username,this.password).subscribe(
            data=>{
              this.cu = data
              alert(this.cu.userId)
              if(this.cu.emailid != ""){
              this.str = this.cu.userId+""
              sessionStorage.setItem('customer', this.str)
              sessionStorage.setItem('productId',this.str1)
              this.router.navigate(['customer'])
              alert("Hello2")
              alert(sessionStorage.length)
              }else{
                this.service.retrieveMerchant(this.username,this.password).subscribe(
                  data=>{
                    this.me = data
                    alert(this.me.merchantId)
                    if(this.me.emailid != ""){
                    this.str = this.me.merchantId+""
                    sessionStorage.setItem('merchant', this.str)
                    this.router.navigate(['merch'])
                    alert("Hello3")
                    alert(sessionStorage.length)
                    }else{
                      alert("invalid")
                    }
                  }
                )
              }
              
            }
          )
        }
      }
    )

  
  }


}
