import { Component } from "@angular/core";
import { AuthenticationService } from "../Services/authentication.service";

@Component({
    selector:'logout',
    template:''
})
export class LogoutComponent{
    constructor(private service:AuthenticationService){
        this.service.logout()
    }
}