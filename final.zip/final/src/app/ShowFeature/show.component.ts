import { Component } from "@angular/core";
import { ProductService } from "../Services/productService";
import { Product } from "../models/product";
import { Sorting } from "../models/sorting";

@Component({
    selector: "show",
    templateUrl: "show.component.html"
})
export class Showcomponent{

    constructor(private service: ProductService){
        this.getProducts();
    }   
    

    products: Product[]=[];

    inputFormat:Sorting={
        category:'Electronics',
        sortingType:''
    }
    
    getProducts(){
        this.service.getProducts().subscribe(
            res=>{
                console.log("here")
                this.products = res;
            }
        )
    }

    showProduct(i){
        let productId = this.products[i].productID
        alert("id is : " + productId)
        this.service.displayProduct(productId) 

    }

    sortProducts(){
        if(this.inputFormat.sortingType==="low_to_high")
            this.service.sortAsc(this.inputFormat).subscribe(
                res=>{
                    this.products = res
                    console.log(res)
                },
                err=>{
                    alert("An error has occurred")
                }
            )

        if(this.inputFormat.sortingType==="high_to_low")
        this.service.sortDesc(this.inputFormat).subscribe(
            res=>{
                this.products = res
                console.log(res)
            },
            err=>{
                alert("An error has occurred")
            }
        )

        if(this.inputFormat.sortingType==="best_seller")
        this.service.sortBestSeller(this.inputFormat).subscribe(
            res=>{
                this.products = res
                console.log(res)
            },
            err=>{
                alert("An error has occurred")
            }
        )
        

    }

    
}