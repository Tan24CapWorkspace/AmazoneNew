import { Component } from "@angular/core";
import { ProductService } from "../Services/productService";
import { Product } from "../models/product";
import { Sorting } from "../models/sorting";
import { AuthenticationService } from "../Services/authentication.service";
import { Router } from "@angular/router";

@Component({
    selector: "show",
    templateUrl: "show.component.html"
})
export class Showcomponent {

    constructor(private service: ProductService, private service1: AuthenticationService, private router: Router) {
        this.getProducts();
    }


    products: Product[] = [];

    inputFormat: Sorting = {
        category: 'Electronics',
        sortingType: ''
    }

    getProducts() {
        this.service.getProducts().subscribe(
            res => {
                console.log("here")
                this.products = res;
            }
        )
    }

    showProduct(i) {
        let productId = this.products[i].productID
        alert("id is : " + productId)
        this.service.displayProduct(productId)

    }

    sortProducts() {
        if (this.inputFormat.sortingType === "low_to_high")
            this.service.sortAsc(this.inputFormat).subscribe(
                res => {
                    this.products = res
                    console.log(res)
                },
                err => {
                    alert("An error has occurred")
                }
            )

        if (this.inputFormat.sortingType === "high_to_low")
            this.service.sortDesc(this.inputFormat).subscribe(
                res => {
                    this.products = res
                    console.log(res)
                },
                err => {
                    alert("An error has occurred")
                }
            )

        if (this.inputFormat.sortingType === "best_seller")
            this.service.sortBestSeller(this.inputFormat).subscribe(
                res => {
                    this.products = res
                    console.log(res)
                },
                err => {
                    alert("An error has occurred")
                }
            )


    }

    checkWishlist() {
        if (sessionStorage.length == 0) {
            alert("Cant display Wishlist!")
            this.router.navigate(['home'])
        }
        else {
            alert("Has value1")
            //return true
        }
    }
    checkOrder() {
        if (sessionStorage.length == 0) {
            alert("Cant display Order!")
            this.router.navigate(['home'])
        }
        else {
            alert("Has value2")
            //return true
        }
    }
    checkReturn() {
        if (sessionStorage.length == 0) {
            alert("Cant display Return!")
            this.router.navigate(['home'])
        }
        else {
            alert("Has value3")
           // return true
        }
    }
    checkCart() {
        if (sessionStorage.length == 0) {
            alert("Cant display Cart!")
            this.router.navigate(['home'])
            
        }
        else {
            alert("Has value4")
            //return true
        }
    }



}